package br.com.calculos.calculos.entity;

public class Resultado {
	
	private Integer soma;
	private Double media;
	
	
	public Integer getSoma() {
		return soma;
	}
	public void setSoma(Integer soma) {
		this.soma = soma;
	}
	public Double getMedia() {
		return media;
	}
	public void setMedia(Double media) {
		this.media = media;
	}

}
