package br.com.calculos.calculos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CalculosApplication {

	public static void main(String[] args) {
		SpringApplication.run(CalculosApplication.class, args);
	}

}
