package br.com.calculos.calculos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CalculosApplicationTests {

	@Test
	void contextLoads() {
	}

}
